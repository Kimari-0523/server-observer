# Server Observer — 纯 Cloudflare 版

本目录包含完整可修改源码、依赖锁文件、测试及部署配置。先阅读 [CLOUDFLARE.md](CLOUDFLARE.md)。

两种方案互相独立；运行凭据由安装者初始化，不随包分发。AI 接入见 docs/AI_ACCESS.md 和 ai-client/README.md；安全与验证边界见 SECURITY.md、VALIDATION.md。MIT 许可证；第三方版权见 THIRD_PARTY_NOTICES.md。
